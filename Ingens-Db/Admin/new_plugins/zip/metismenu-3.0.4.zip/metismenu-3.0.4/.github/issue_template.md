Welcome to the metismenu issues!

Please take a moment to:

- Read the Contributing Guide (found at https://github.com/onokumus/metismenu/tree/master/.github/contributing.md)
- Review the project readme (you might find advice about creating new issues)


Once have reviewed both documents, please delete everything up to and including this line and provide the following details.


## Version

_(note the version of metismenu you were using when you experienced the issue (this is **required** for bug reports)

**version**:

## Description



## Error message

```sh
# please paste any error messages here
```

## metisMenu.js

```js
// Please paste contents of metisMenu.js here, or in a gist.
// Be sure to include any additional comments that might help
// us resolve the issue.
```
