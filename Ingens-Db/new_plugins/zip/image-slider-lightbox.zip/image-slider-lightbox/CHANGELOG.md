# CHANGELOG

## 0.1.1

* Fix wheel event handling.
* Fix page up/down key actions.
* Hide scrollbar.
* Hide loading text after content loaded.
* Don't initialize image translation on window resize.

## 0.1.0

* First release.
