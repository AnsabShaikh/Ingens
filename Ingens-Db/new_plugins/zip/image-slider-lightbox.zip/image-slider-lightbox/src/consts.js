export const NAMESPACE = 'simple-lightbox';
